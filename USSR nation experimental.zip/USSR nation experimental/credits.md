**Version 1.0**

## CREDITS:

Thanks **Unciv Gaming** on Discord for making the jsons of USSR! I made it turn into a reality.

Nation Icons:

* USSR - [Hammer and Sickle](https://thenounproject.com/icon/99798/) by **bdeb**

Unit Icons:

* Katyusha - [Missiles](https://thenounproject.com/icon/2052175/) by **Vectors Market**
* T-34 - [Tank](https://thenounproject.com/icon/248489/) by **Evgeniy Kozachenko**
* Tsar Bomba - [nuclear explosion](https://thenounproject.com/icon/777683/) by **Aldric Rodríguez**

Unit Sprites made by **The Bucketeer** on Discord
