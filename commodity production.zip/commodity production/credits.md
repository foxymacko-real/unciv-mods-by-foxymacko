**Version 0.1*** 
made by foxymacko
yes
adds 2 buildings