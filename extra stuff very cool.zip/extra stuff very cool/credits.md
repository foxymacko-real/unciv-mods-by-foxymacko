**Version 0.1*** 
made by foxymacko
yes
adds few buildings
mostly late game for settling the artic and coping with alot of population